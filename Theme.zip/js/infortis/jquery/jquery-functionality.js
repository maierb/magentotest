jQuery(document).ready(function(){
  jQuery('#search').attr('value', 'jQuery is ready!!!');
})