//Avoid PrototypeJS conflicts, assign jQuery to $j instead of $
var $j = jQuery.noConflict();