<?php

class Infortis_CloudZoom_Block_Product_View_LightboxConfig extends Mage_Core_Block_Template
{
}
