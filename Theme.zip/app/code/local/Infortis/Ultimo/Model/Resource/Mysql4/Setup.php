<?php
/**
 * Infortis Ultimo
 */

class Infortis_Ultimo_Model_Resource_Mysql4_Setup extends Mage_Core_Model_Resource_Setup
{
}
